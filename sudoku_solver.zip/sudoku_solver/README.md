# Solving Sudoku with Constraint Satisfaction Problems 

This project implements a Sudoku puzzle solver using the Constraint Satisfaction Problems approach. The solver is capable of finding solutions for 9x9 Sudoku puzzles.

## Introduction to Sudoku

Sudoku is a puzzle that challenges players to fill a 9x9 grid with digits so that each column, each row, and each of the nine 3x3 subgrids contains all the digits from 1 to 9, without any repetition. The puzzle provides a partially filled grid, and the player must use logic and deduction to complete the grid while satisfying the given constraints.

## Algorithm

The Sudoku solver implemented in this project uses the CSP approach to find solutions. The solving process involves the following steps:

1. **Variable Definition**: Each empty cell in the Sudoku grid is considered a variable. The variables are represented by their respective row and column indices.

2. **Domain Definition**: The domain of each variable is defined as the set of possible values that can be assigned to that cell. Initially, the domain for each empty cell includes all the numbers from 1 to 9.

3. **Constraint Definition**: The constraints in Sudoku ensure that each row, column, and 3x3 subgrid contains only unique values from 1 to 9. These constraints are explicitly defined in the solver.

4. **Constraint Propagation**: Constraint propagation techniques, such as forward checking and arc consistency, are applied to reduce the domains of variables based on the constraints. This helps in pruning the search space and improving the efficiency of the solver.

5. **Backtracking Search**: The solver employs a backtracking search algorithm to explore the possible solutions. It assigns values to variables one by one, and if a constraint violation occurs, it backtracks and tries a different value. The search is guided by heuristics like Minimum Remaining Values (MRV) and Least Constraining Value (LCV) to make intelligent variable and value selections.

6. **Solution**: If the solver finds a solution that satisfies all the constraints, it returns the solved Sudoku grid. If no solution is found, it indicates that the puzzle is unsolvable.

## Example Puzzle and Solution

Consider the following Sudoku puzzle:
```
6 . . 8 . 7 . 2 1
. 4 . . 1 . . . 2
. . 2 . 5 . . 4 .
7 . 1 . 8 . 4 . 5
. . . . . . . . .
5 . 9 . 6 . 3 . 1
. 6 . . 7 . 5 . .
2 . . . 9 . . 8 .
1 5 . 2 . 3 . . 6
```

#### Step 1: Variable Definition and Domain Assignment
- The solver defines variables for each empty cell, represented by their row and column indices.
- Initially, the domain of each empty cell is set to `{1, 2, 3, 4, 5, 6, 7, 8, 9}`.

#### Step 2: Constraint Propagation
- The solver applies constraint propagation techniques to reduce the domains of variables based on the given values and constraints.
- For example, considering the first row:
  - The domain of `(0, 1)` is reduced to `{3, 5}` because `6`, `8`, `7`, `2`, and `1` are already present in the row.
  - Similarly, the domain of `(0, 6)` is reduced to `{9}` because it is the only missing value in the row.
- The solver continues this process for all rows, columns, and subgrids.

#### Step 3: Backtracking Search
- The solver starts the backtracking search by selecting the variable with the minimum remaining values.
- Let's say the solver selects the variable `(4, 0)`, which has the domain `{3, 4, 8, 9}` after constraint propagation.
- It assigns the least constraining value from the domain, let's say `3`.
- The solver then propagates the constraints and updates the domains of the affected variables.
  - After assigning `3` to `(4, 0)`, the domain of `(4, 1)` is reduced to `{8}` because `3` is no longer a valid option.
- If no constraint violation is detected, the solver moves on to the next variable.
- Let's say the solver selects the variable `(4, 2)`, which has the domain `{4, 8}` after constraint propagation.
- It assigns the least constraining value, let's say `8`.
- The solver continues this process, assigning values to variables and propagating constraints.

#### Step 4: Backtracking
- If a constraint violation is detected during the search, the solver backtracks to the previous variable and tries a different value.
- For example, if assigning `8` to `(4, 2)` leads to a constraint violation, the solver backtracks to `(4, 1)` and tries a different value from its domain.

#### Step 5: Solution
- The solver continues the backtracking search, assigning values to variables and propagating constraints until all cells are filled and no constraint violations are detected.
- After the solving process, the solver outputs the completed Sudoku grid:

```
6 3 5 8 4 7 9 2 1
8 4 7 3 1 9 6 5 2
9 1 2 6 5 8 7 4 3
7 2 1 9 8 6 4 3 5
3 8 4 5 2 1 7 9 6
5 7 9 4 6 2 3 8 1
4 6 8 1 7 5 2 9 3
2 5 3 7 9 4 1 8 6
1 9 7 2 3 5 8 6 4
```

## Usage

To use the Sudoku solver, follow these steps:

1. In terminal, type `python app.py` (or click on it here directly)
2. Directly double click on the application `sudoku_solver_good_jingwen.exe` (Windows)
