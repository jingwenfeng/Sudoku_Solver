from flask import Flask, render_template, request, session, redirect
from flask_session import Session
from sudoku_solver import SudokuSolver
import random

app = Flask(__name__)
app.secret_key = 'sudoku_solver_secret'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

def generate_random_puzzle(cells_to_remove=40):
    def is_valid_placement(board, row, col, num):
        for i in range(9):
            if board[row][i] == num or board[i][col] == num:
                return False
        startRow, startCol = 3 * (row // 3), 3 * (col // 3)
        for i in range(3):
            for j in range(3):
                if board[i + startRow][j + startCol] == num:
                    return False
        return True

    def fill_board(board):
        for i in range(9):
            for j in range(9):
                if board[i][j] == 0:
                    random_nums = list(range(1, 10))
                    random.shuffle(random_nums)
                    for num in random_nums:
                        if is_valid_placement(board, i, j, num):
                            board[i][j] = num
                            if not any(0 in row for row in board) or fill_board(board):
                                return True
                            board[i][j] = 0
                    return False
        return True

    def remove_numbers_from_board(board):
        count = cells_to_remove
        while count > 0:
            row, col = random.randint(0, 8), random.randint(0, 8)
            if board[row][col] != 0:
                board[row][col] = 0
                count -= 1

    board = [[0 for _ in range(9)] for _ in range(9)]
    fill_board(board)
    remove_numbers_from_board(board)
    return board


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'solve' in request.form:
            puzzle = []
            valid_input = True
            for i in range(9):
                row = []
                for j in range(9):
                    cell_value = request.form.get(f'cell-{i}{j}', '').strip()
                    if cell_value == '':
                        row.append(0)
                    elif cell_value.isdigit() and 1 <= int(cell_value) <= 9:
                        row.append(int(cell_value))
                    else:
                        valid_input = False
                        break
                puzzle.append(row)
                if not valid_input:
                    break

            if valid_input:
                solver = SudokuSolver(puzzle)
                if solver.solve():
                    session['puzzle'] = solver.board
                    return render_template('solution.html', puzzle=solver.board, solved=True)
                else:
                    return render_template('solution.html', puzzle=puzzle, solved=False)
            else:
                return render_template('index.html', puzzle=puzzle, error="Invalid input. Please enter numbers from 1 to 9.")
        elif 'generate' in request.form:
            puzzle = generate_random_puzzle()
            session['puzzle'] = puzzle
            return render_template('index.html', puzzle=puzzle)
    else:
        puzzle = session.get('puzzle', [[0 for _ in range(9)] for _ in range(9)])
    return render_template('index.html', puzzle=puzzle)

@app.route('/reset', methods=['GET'])
def reset():
    session.pop('puzzle', None)
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)